#!/bin/bash
adb devices;
adb devices;
adb connect $1;
./run.sh -P 1920x1080@960x540/0 $1 && PORT=9002 node example/app.js &

